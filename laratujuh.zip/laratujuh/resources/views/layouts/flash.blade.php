 @if(session()->has('message'))
 <div class="allert alert-success">{{session()->get('message')}}</div>
 @elseif(session()->has('error'))
 <div class="allert alert-danger">{{session()->get('error')}}</div>
 @endif