<div>
    <div class="flex justify-center pb-4 px-4">
                <h2 class="text-lg pb-4">Add Steps for task</h2>
                <span wire:click="increment" class= "fas fa-plus px-2 py-1 cursor-pointer" />
            </div>

            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex justify-center py-2" wire:key="<?php echo e($step); ?>">
                <input type="text" name="step[]" class="py-1 px-2 border rounded" 
                placeholder="<?php echo e('Describe Step '.($step+1)); ?>" />
                <span class="fas fa-times text-red-400 p-2" wire:click="remove(<?php echo e($step); ?>)" />
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\laratujuh\resources\views/livewire/step.blade.php ENDPATH**/ ?>