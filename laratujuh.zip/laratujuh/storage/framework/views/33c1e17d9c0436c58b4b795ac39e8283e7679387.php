 <?php if(session()->has('message')): ?>
 <div class="allert alert-success"><?php echo e(session()->get('message')); ?></div>
 <?php elseif(session()->has('error')): ?>
 <div class="allert alert-danger"><?php echo e(session()->get('error')); ?></div>
 <?php endif; ?><?php /**PATH C:\xampp\htdocs\laratujuh\resources\views/layouts/flash.blade.php ENDPATH**/ ?>