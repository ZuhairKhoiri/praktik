 


<?php $__env->startSection('content'); ?>
<div class="flex justify-between border-b pb-4 px-4">
    <h1 class="text-2xl">All Your Todos</h1>
    <a href="<?php echo e(route('todo.create')); ?>" class="mx-5 py-2 text-blue-400 cursor-pointer text-white" >
    <span class= "fas fa-plus-circle" />
</a>
</div>
            <ul class="my-5">
             <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  
                <?php $__empty_1 = true; $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="flex justify-between p-2">
                    <div> 
                        <?php echo $__env->make('todos.complete-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    
                    <?php if($todo->completed): ?>
                    <p class="line-through"><?php echo e($todo->title); ?></p>
                    <?php else: ?>
                    <a class="cursor-pointer" href="<?php echo e(route('todo.show',$todo->id)); ?>"><?php echo e($todo->title); ?></a>
                    <?php endif; ?>
                    
                    <div>
                   <a href="<?php echo e(route('todo.edit',$todo->id)); ?>" class="text-orange-400
                    cursor-pointer text-white">
                   <span class="fas fa-edit px-2" /> </a>
                   
                    <span class="fas fa-trash text-red-500 px-2 cursor-pointer"
                            onclick="event.preventDefault();
                            if(confirm('kamu yakin mau dihapus ?')){
                                document.getElementById('form-delete-<?php echo e($todo->id); ?>')
                                .submit()}"/>
                                
                   <form style="display:none" id="<?php echo e('form-delete-'.$todo->id); ?>"
                    method="post" action="<?php echo e(route('todo.destroy',$todo->id)); ?>">
                   <?php echo csrf_field(); ?>
                   <?php echo method_field('delete'); ?> 
                   </form>
                   <!-- <?php if($todo->completed): ?>
                   <span class="fas fa-check text-green-400 cursor-pointer px-2" onclick="event.preventDefault();
                                    document.getElementById('form-incomplete-<?php echo e($todo->id); ?>')
                                    .submit()" />
                    <form style="display:none" id="<?php echo e('form-incomplete-'.$todo->id); ?>" method="post" action="<?php echo e(route('todo.incomplete',$todo->id)); ?>">
                   <?php echo csrf_field(); ?>
                   <?php echo method_field('delete'); ?>

                   <?php else: ?> 
                   <span onclick="event.preventDefault();
                                    document.getElementById('form-complete-<?php echo e($todo->id); ?>')
                                    .submit()" 
                                    class="fas fa-check text-gray-300 cursor-pointer px-2" />

                   <form style="display:none" id="<?php echo e('form-complete-'.$todo->id); ?>" method="post" action="<?php echo e(route('todo.complete',$todo->id)); ?>">
                   <?php echo csrf_field(); ?>
                   <?php echo method_field('put'); ?> -->
                   <!-- </form> -->
                   <!-- <?php endif; ?> -->
                     </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>Tidak ada task, Buatlah Satu !</p>
                <?php endif; ?>
            </ul>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('todos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratujuh\resources\views/todos/index.blade.php ENDPATH**/ ?>