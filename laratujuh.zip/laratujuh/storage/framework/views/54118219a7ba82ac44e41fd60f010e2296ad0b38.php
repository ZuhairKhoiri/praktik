


<?php $__env->startSection('content'); ?>
<div class="flex justify-between border-b pb-4 px-4">
<h1 class="text-2xl pb-4">What next you To-Do</h1>
    <a href="<?php echo e(route('todo.index')); ?>" class="mx-5 py-2 text-gray-400 cursor-pointer text-white" >
    <span class= "fas fa-arrow-left" />
</a>
</div>
     <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <form method="post" action="<?php echo e(route('todo.store')); ?>" class="py-5">
            <?php echo csrf_field(); ?>
            <div class="py-1">
            <input type="text" name="title" class="py-2 px-2 border rounded" 
            placeholder="Title" />
            </div>
            <div class="py-1">
            <textarea name="description" class ="p-1 rounded border" id="" cols="30" rows="10" 
            placeholder="description"></textarea>
            </div>

            <div class="py-2">
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('step')->html();
} elseif ($_instance->childHasBeenRendered('Mo1LaMs')) {
    $componentId = $_instance->getRenderedChildComponentId('Mo1LaMs');
    $componentTag = $_instance->getRenderedChildComponentTagName('Mo1LaMs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Mo1LaMs');
} else {
    $response = \Livewire\Livewire::mount('step');
    $html = $response->html();
    $_instance->logRenderedChild('Mo1LaMs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
            
            </div>
            <div class="py-1">
            <input type="submit" value="Create" class="p-2 border rounded" />
            </div>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('todos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratujuh\resources\views/todos/create.blade.php ENDPATH**/ ?>