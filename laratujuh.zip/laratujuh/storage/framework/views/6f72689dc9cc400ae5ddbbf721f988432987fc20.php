


<?php $__env->startSection('content'); ?>
<div class="flex justify-between border-b pb-4 px-4">
<h1 class="text-2xl pb-4"><?php echo e($todo->title); ?></h1>
    <a href="<?php echo e(route('todo.index')); ?>" class="mx-5 py-2 text-gray-400 cursor-pointer text-white" >
    <span class= "fas fa-arrow-left" />
</a>
</div>
    <div>

        <div>
            <h3 class="text-lg">Description</h3>
            <p><?php echo e($todo->description); ?></p>
        </div>

        <?php if($todo->steps->count() > 0): ?>
        <div class="py-4">
        <h3 class="text-lg">Step for this task</h3>
        <?php $__currentLoopData = $todo->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($step->name); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

    </div>
    
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('todos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratujuh\resources\views/todos/show.blade.php ENDPATH**/ ?>