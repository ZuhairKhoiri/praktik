<div>
    <button wire:click="increment">+</button>
    <h1><?php echo e($count); ?></h1>
    <button wire:click="decrement">-</button>
</div>
<?php /**PATH C:\xampp\htdocs\laratujuh\resources\views/livewire/counter.blade.php ENDPATH**/ ?>