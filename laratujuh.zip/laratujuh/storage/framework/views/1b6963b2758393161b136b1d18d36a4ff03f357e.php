<div>
    <div class="flex justify-center pb-4 px-4">
                <h2 class="text-lg pb-4">Add Steps for task</h2>
                <span wire:click="increment" class= "fas fa-plus px-2 py-1 cursor-pointer" />
            </div>

            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex justify-center py-2" wire:key="<?php echo e($loop->index); ?>">
                <input type="text" name="stepName[]" class="py-1 px-2 border rounded" placeholder="<?php echo e('Describe Step '.
                ($loop->index+1)); ?>" value="<?php echo e($step['name']); ?>" />
                <input type="hidden" name="stepId[]" value="<?php echo e($step['id']); ?>" />
                <span class="fas fa-times text-red-400 p-2" wire:click="remove(<?php echo e($loop->index); ?>)" />
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\laratujuh\resources\views/livewire/edit-step.blade.php ENDPATH**/ ?>