

<?php $__env->startSection('content'); ?>
<div class="flex justify-between border-b pb-4 px-4">
<h1 class="text-2xl pb-4">Update this todo list</h1>
    <a href="<?php echo e(route('todo.index')); ?>" class="mx-5 py-2 text-gray-400 cursor-pointer text-white" >
    <span class= "fas fa-arrow-left" />
</a>
</div>
    <!-- <?php echo e($todo->title); ?> -->
    
    <!-- <h2><?php echo e($todo->title); ?></h2> -->
     <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <form method="post" action="<?php echo e(route('todo.update',$todo->id)); ?>" class="py-5">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="py-1">
            <input type="text" name="title" value="<?php echo e($todo->title); ?>" class="py-2 px-2 
            border rounded" placeholder="Title"/>
            </div>
            <div class="py-1">
            <textarea name="description" class ="p-1 rounded border" id="" cols="30" rows="10" 
            placeholder="description"><?php echo e($todo->description); ?></textarea>
            </div>

            <div class="py-2">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('edit-step',['steps' => $todo->steps])->html();
} elseif ($_instance->childHasBeenRendered('2vR2ihp')) {
    $componentId = $_instance->getRenderedChildComponentId('2vR2ihp');
    $componentTag = $_instance->getRenderedChildComponentTagName('2vR2ihp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2vR2ihp');
} else {
    $response = \Livewire\Livewire::mount('edit-step',['steps' => $todo->steps]);
    $html = $response->html();
    $_instance->logRenderedChild('2vR2ihp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>

            <div class="py-1">
            <input type="submit" value="Update" class="p-2 border rounded" />
            </div>        
        </form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('todos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laratujuh\resources\views/todos/edit.blade.php ENDPATH**/ ?>