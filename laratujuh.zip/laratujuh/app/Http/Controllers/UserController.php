<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\User;

class UserController extends Controller
{   
    public function uploadAvatar(Request $request)
    {
        if($request->hasFile('image')){
            $this->deleteOldImage();
            User::uploadAvatar($request->image);
            return redirect()->back()->with('message','Gambar berhasil di upload.'); //success message
        }
        return redirect()->back()->with('error','Gambar gagal di upload.'); //error message 
    }

    protected function deleteOldImage()
    {
        if(auth()->user()->avatar) {
            Storage::delete('public/images/'. auth()->user()->avatar);
        }
    }

    public function index()
    {
        $data = [
            'name'     => 'Femo',
            'email'    => 'femo@gmail.com',
            'password' =>  'password',
        ];
         
        User::create($data);
        // $user               = new User();
        // $user->name         = 'undha';
        // $user->email        = 'undha@undha.ac.id';
        // $user->password     = bcrypt('password') ;
        // $user->save();

        $user = User::all();
        return $user;

        // User::where('id', 7)->delete();

        // User::where('id', 9)->update(['name' =>
        // 'undhaaaaaaaa']);

        // DB::insert ('insert into users (name,email,password) 
        // values (?,?,?)', [
        //     'UNDHA','UNDHA@undha.ac.id','password',
        // ]);
        // $users =  DB::select('select * from users');
        // return $users;
        // DB::update('update users set name = ? where id = 
        // 1',['stmik']);   

        // DB::delete('delete from users where id=1');

        // $users =  DB::select('select * from users');
        // return $users;

        return view ('home');
    }
}
