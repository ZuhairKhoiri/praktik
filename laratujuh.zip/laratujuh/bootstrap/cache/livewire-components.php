<?php return array (
  'edit-step' => 'App\\Http\\Livewire\\EditStep',
  'step' => 'App\\Http\\Livewire\\Step',
);